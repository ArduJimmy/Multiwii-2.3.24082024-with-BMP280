# Multiwii-2.3-with-BMP280
Multiwii brushed quadcopter with bmp280 module

<p>All wiring and schematic is based on: <a href="https://github.com/ArduJimmy/ArduJimmy-Brushed-QuadX-With-Flysky">Multiwii 2.3 Brushed QuadX</a></p>

<img src="https://github.com/ArduJimmy/Multiwii-2.3-with-BMP280/blob/main/BMP280.png" alt="Multiwii with bmp280"/>

<h3>WARNING!</h3>
<p>This code is not being tested (since I have no bmp280 with me). If you use this modified multiwii 2.3 version. It's your own Risk !!!</p>
<p>I will test it as soon as I get the module and show you HOW it works through my <a href="https://www.youtube.com/@Ardujimmy">Ardujimmy</a> YT channel</p>
